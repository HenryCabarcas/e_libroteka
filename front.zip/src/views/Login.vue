<template>
  <h1>Login Page</h1>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {
      user: "",
      password: "",
    };
  },
};
</script>

<style></style>
